
<?php
$menuItems = $connection->getMenuItems();
?>




        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">

<!--            <div class="list-group">-->
<!--                <a href="#" class="list-group-item list-group-item-action active" aria-current="true">-->
<!--                    The current link item-->
<!--                </a>-->
<!--                <a href="#" class="list-group-item list-group-item-action">A second link item</a>-->
<!--                <a href="#" class="list-group-item list-group-item-action">A third link item</a>-->
<!--                <a href="#" class="list-group-item list-group-item-action">A fourth link item</a>-->
<!--                <a href="#" class="list-group-item list-group-item-action disabled" tabindex="-1" aria-disabled="true">A disabled link item</a>-->
<!--            </div>-->
<!--            -->







            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">

                    <!-- Sidebar - Brand -->
                    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo CoreFunctions::PAGE_HOMEPAGE; ?>">
                        <div class="sidebar-brand-icon rotate-n-15">
                            <i style="color: lightgrey" class="fas fa-laugh-wink"></i>
                        </div>
                        <div style="color: lightgrey" class="sidebar-brand-text mx-3">BADI</sup></div>
                    </a>

                    <!-- Divider -->
                    <hr class="sidebar-divider my-0">





<!--                    MENU-->

<!--                    Schovavanie ak je prihlaseny-->
                     <?php
                         if (CoreFunctions::isGranted()) {
                             foreach ($menuItems as $item) {
                     ?>
                         <li class="nav-item">
                             <a href="<?php echo $item['href'] ?>" class="nav-link align-middle px-0">
                                 <i style="color: lightgrey" class="<?php echo $item['data-feather'] ?>"></i>
                                 <span style="color: lightgrey; class="ms-1 d-none d-sm-inline"><?php echo $item['name'] ?></span>
                             </a>
                         </li>
                    <?php
                    }
                    } else {
                             ?>
                             <li class="nav-item">
                                 <a href="<?php echo CoreFunctions::PAGE_LOGIN; ?>" class="nav-link align-middle px-0">
                                     <i style="color: lightgrey" class="fas fa-user"></i>
                                     <span style="color: lightgrey; class="ms-1 d-none d-sm-inline">Sign in</span>
                                 </a>
                             </li>
                    <?php

                         }
                    ?>
                </ul>



                <?php if (CoreFunctions::isGranted()) { ?>
                    <hr>
                    <div class="dropdown pb-4">
                        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="https://github.com/mdo.png" alt="hugenerd" width="30" height="30" class="rounded-circle">
                            <span class="d-none d-sm-inline mx-1">loser</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                            <li><a class="dropdown-item" href="#">New project...</a></li>
    <!--                        <li><a class="dropdown-item" href="#">Settings</a></li>-->
                            <li><a class="dropdown-item" href="#">Profile</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="<?php echo CoreFunctions::ACTION_LOGOUT; ?>">Sign out</a></li>
                        </ul>
                    </div>
                <?php } ?>
            </div>
        </div>
